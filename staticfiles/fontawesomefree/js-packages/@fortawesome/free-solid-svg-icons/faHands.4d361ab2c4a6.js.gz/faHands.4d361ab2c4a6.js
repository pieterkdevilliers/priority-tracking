'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'hands';
var width = 512;
var height = 512;
var aliases = ["sign-language","signing"];
var unicode = 'f2a7';
var svgPathData = 'M154.9 162c.3 .7 .7 1.5 1.1 2.2l17.8 30.9c11.1-12.6 27.4-19.8 44.4-19.1l-20.7-35.8c-6.6-11.5-21.3-15.4-32.8-8.8c-10.8 6.2-14.9 19.5-9.9 30.6zm173.6 47C399.7 231.7 448 297.8 448 372.5c0 1.5 0 3-.1 4.5c39.7-25.6 64.1-69.7 64.1-117.4V136c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 81.7L347.8 16.5C341.2 5 326.5 1.1 315.1 7.7s-15.4 21.3-8.8 32.8l64 110.9c2.2 3.8 .9 8.7-2.9 10.9s-8.7 .9-10.9-2.9l-80-138.6C269.8 9.3 255.1 5.4 243.6 12s-15.4 21.3-8.8 32.8l80 138.6c2.2 3.8 .9 8.7-2.9 10.9s-8.7 .9-10.9-2.9L237 80.5c-6.6-11.5-21.3-15.4-32.8-8.8s-15.4 21.3-8.8 32.8l44 76.2L328.5 209zM64 488c0 12.4 9.4 22.6 21.5 23.9c.8 .1 1.6 .1 2.5 .1H288.7 296c66.3 0 120-53.7 120-120c0-1.2 0-2.4-.1-3.6c0-1.2 .1-2.5 .1-3.7c0-68-44-128.2-108.9-148.9l-83.9-26.7c-12.6-4-26.1 3-30.1 15.6s3 26.1 15.6 30.1L262.6 272H56c-13.3 0-24 10.7-24 24s10.7 24 24 24H184c4.4 0 8 3.6 8 8s-3.6 8-8 8H24c-13.3 0-24 10.7-24 24s10.7 24 24 24H184c4.4 0 8 3.6 8 8s-3.6 8-8 8H56c-13.3 0-24 10.7-24 24s10.7 24 24 24H184c4.4 0 8 3.6 8 8s-3.6 8-8 8H88c-13.3 0-24 10.7-24 24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faHands = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;